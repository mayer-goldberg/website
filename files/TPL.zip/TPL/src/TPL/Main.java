package TPL;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Entry point for TPL front-end.
 * 
 */
public class Main {
	public static void main(String[] args) {
		if (args.length == 2 && args[0].equals("-printTokens"))
			printTokens(args[1]);
	}

	/**
	 * Prints the list of tokens, one token per line.
	 * 
	 * @param filename
	 *            The name of the input TPL file.
	 */
	public static void printTokens(String filename) {
		FileReader txtFile;
		try {
			txtFile = new FileReader(filename);
			Lexer scanner = new Lexer(txtFile);
			Token token = null;
			do {
				token = scanner.next_token();
				if (token != null) {
					System.out.println(token.toString());
				}
			} while (token != null && token.sym != sym.EOF);
		} catch (FileNotFoundException e) {
			System.out.print("File not found: " + filename);
		} catch (IOException e) {
			System.out.print("Error reading file: " + filename);
		} catch (LexicalError e) {
			System.out.print(e.formatErrorMessage());
		}
	}

	public static void autoFormat(String inputFilename, String outputFileName) {
		// To be implemented in Parsing assignment.
	}
}