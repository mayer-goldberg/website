package TPL;

import java.lang.reflect.Field;

import java_cup.runtime.Symbol;

/**
 * A basic lexical unit in TPL.
 *
 */
public class Token extends Symbol {
	public final int line;
	protected float number;
	protected String quote;	

	public Token(int id, int line) {
		super(id, null);
		this.line = line;
	}

	public Token(int id, int line, String value) {
		super(id, null);
		this.line = line;
		this.quote = value;
	}

	public Token(int id, int line, float value) {
		super(id, null);
		this.line = line;
		this.number = value;
	}

	public String toString() {
		Field[] fields = TPL.sym.class.getFields();
		for (Field field : fields) {
			try {
				int val = field.getInt(field);
				if (val == sym) {
					String result = field.getName();
					if (sym == TPL.sym.QUOTE)
						result += "(" + quote + ")";
					if (sym == TPL.sym.NUM)
						result += "(" + number + ")";
					return result;
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}